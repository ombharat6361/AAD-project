package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottom;
    ArrayList<Product> products;
    ArrayList<Product> cart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottom=findViewById(R.id.bottom);

        products=new ArrayList<>();
        cart=new ArrayList<>();

        loadProducts();


//        Intent rec=getIntent();
        Bundle b=getIntent().getExtras();
        String name = null;
        if (b != null) {
            name = b.getString("Product");


            if ("helmet".equals(name)) {
                cart.add(products.get(0));
            } else if ("Seat".equals(name)) {
                cart.add(products.get(1));
            } else {
                cart.add(products.get(2));
            }
        }

        bottom.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id=item.getItemId();

                if(id==R.id.home)
                {
                    LoadFragment(new Home(products));
                }
                else if(id==R.id.cart)
                {
                    LoadFragment(new Cart(cart));
                }
                else
                {
                    LoadFragment(new Contact());
                }
                return true;
            }
        });
        bottom.setSelectedItemId(R.id.home);
    }
    public void LoadFragment(Fragment fragment)
    {
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        ft.replace(R.id.container, fragment);
        ft.commit();
    }
    public void loadProducts()
    {
        Product helmet=new Product("helmet", "Hard shell helmet | Fixed visor | Basic quality", 500);
        Product seat=new Product("Seat", "Brown leather | Metallic finish | Basic finish", 450);
        Product sidebag=new Product("Side Bag", "Single pocket | Premium leather", 300);

        products.add(helmet);
        products.add(seat);
        products.add(sidebag);
    }
}
