package com.example.project;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class Cart extends Fragment {
    ArrayList<Product> cart;
    ListView c;

    public Cart(ArrayList<Product> cart) {
        // Required empty public constructor
        this.cart=new ArrayList<>();
        this.cart=cart;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_cart, container, false);

        c=view.findViewById(R.id.cart);

//        int i=cart.size();
//        String[] names=new String[i];
//        int[] costs=new int[i];
//
//        for(int j=0; j<i; j++)
//        {
//            names[i]=cart.get(i).name;
//            costs[i]=cart.get(i).cost;
//        }

        ProductAdapter adapter=new ProductAdapter(getContext(), R.layout.cart_list, cart);
        c.setAdapter(adapter);
        return view;
    }
}