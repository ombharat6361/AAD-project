package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ProductDisplay extends AppCompatActivity {

    TextView prod_name, prod_desc, prod_cost;
    Button cart;
    Product prod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_display);

        prod_name=findViewById(R.id.prod_name);
        prod_cost=findViewById(R.id.prod_cost);
        prod_desc=findViewById(R.id.prod_desc);
        cart=findViewById(R.id.cart);

//        prod=new Product();
        Intent rec=getIntent();
        String name=rec.getStringExtra("ProductName");
        String desc=rec.getStringExtra("ProductDesc");
        int cost=rec.getIntExtra("ProductCost", 0);

        prod_name.setText("Name: "+name);
        prod_cost.setText("Cost: "+cost);
        prod_desc.setText("Description: "+desc);

        Intent added = new Intent(this, MainActivity.class);

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                added.putExtra("Product", name);
                startActivity(added);

                Toast.makeText(getApplicationContext(), "Added to cart", Toast.LENGTH_SHORT).show();
            }
        });

    }


}