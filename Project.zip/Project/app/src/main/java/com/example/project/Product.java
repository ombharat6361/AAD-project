package com.example.project;


import java.io.Serializable;

public class Product implements Serializable {
        String name,description;
        int cost;
//        int pictureID;

    public Product()
    {

    }

    public Product(String name,String description,int cost)
        {
        this.name=name;
        this.description=description;
        this.cost=cost;
//        this.pictureID=pictureID;
        }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getCost() {
        return cost;
    }
//
//    public int getPictureID() {
//        return pictureID;
//    }
}
