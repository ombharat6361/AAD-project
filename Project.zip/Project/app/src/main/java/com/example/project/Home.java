package com.example.project;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;


public class Home extends Fragment {
    ListView p_list;
    ArrayList<Product> products;

    String[] names;

    public Home(ArrayList<Product> products) {
        // Required empty public constructor
        this.products=new ArrayList<>();
        this.products=products;
        names=new String[3];
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home, container, false);
        p_list=(ListView) view.findViewById(R.id.p_list);
        loadProducts();
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.activity_listview, names);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), R.layout.activity_listview, names);

//        MainActivity m= (MainActivity) getActivity();

//        ProductAdapter adapter=new ProductAdapter(getContext(),0, products);
        p_list.setAdapter(adapter);

        p_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0)
                {
                    goToDisplay(products.get(0));
                }
                else if (i==1)
                {
                    goToDisplay(products.get(1));
                }
                else
                {
                    goToDisplay(products.get(2));
                }
            }
        });

        return view;
    }

    public void loadProducts()
    {

        names[0]="Helmet";
        names[1]="Seat";
        names[2]="Side bag";

    }

    public void goToDisplay(Product p)
    {
        Intent intent = new Intent(getActivity(), ProductDisplay.class);
        intent.putExtra("ProductName", p.name);
        intent.putExtra("ProductCost", p.cost);
        intent.putExtra("ProductDesc", p.description);
        startActivity(intent);
    }
}