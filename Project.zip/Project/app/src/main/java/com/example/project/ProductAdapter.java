package com.example.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends ArrayAdapter<Product> {

    ArrayList<Product> products;

    static class ProductViewHolder
    {
        TextView name;
        TextView cost;
    }

    public ProductAdapter(@NonNull Context context, int resource, ArrayList<Product> products) {
        super(context,resource);
        this.products=products;
    }

    public int getCount()
    {
        return this.products.size();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView,@NonNull ViewGroup parent)
    {

        ProductViewHolder vh;
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.cart_list, parent, false);

            vh=new ProductViewHolder();
            vh.name=(TextView) convertView.findViewById(R.id.name);
            vh.cost=(TextView) convertView.findViewById(R.id.cost);

            convertView.setTag(vh);
        }
        else
            vh=(ProductViewHolder)convertView.getTag();


//        TextView qty=convertView.findViewById(R.id.qty);


        vh.name.setText(products.get(position).name);
        vh.cost.setText(""+products.get(position).cost);
//        cost.setText(p.getCost());
//        qty.setText(p.getQty());


        return convertView;
    }
}
